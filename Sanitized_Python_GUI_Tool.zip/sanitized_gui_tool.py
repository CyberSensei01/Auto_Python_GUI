import tkinter as tk
from tkinter import messagebox
import subprocess
import random
import time

def ytype(text, delay=0.05):
    subprocess.run(["ydotool", "type", text])
    time.sleep(delay * len(text))

def submit_action():
    location = location_var.get()
    unit = unit_var.get()
    identifier = identifier_var.get()

    if not location or not unit:
        messagebox.showwarning("Input Error", "Location and Unit are required.")
        return

    formatted = f"PREFIX-{location.zfill(4)}X{unit.zfill(2)}Y{random.randint(0,99):02d}"
    app.withdraw()
    time.sleep(0.5)

    ytype(f"entry-{formatted}")
    ytype("\t")
    ytype(identifier)
    ytype("\n")
    messagebox.showinfo("Done", "Identifier sequence sent.")
    app.deiconify()

app = tk.Tk()
app.title("Placeholder Entry Tool")

tk.Label(app, text="Location Code:").grid(row=0, column=0, sticky="e")
tk.Label(app, text="Unit Number:").grid(row=1, column=0, sticky="e")
tk.Label(app, text="Identifier:").grid(row=2, column=0, sticky="e")

location_var = tk.StringVar()
unit_var = tk.StringVar()
identifier_var = tk.StringVar(value="IDENTIFIER123")

tk.Entry(app, textvariable=location_var).grid(row=0, column=1)
tk.Entry(app, textvariable=unit_var).grid(row=1, column=1)
tk.Entry(app, textvariable=identifier_var).grid(row=2, column=1)

tk.Button(app, text="Submit", command=submit_action).grid(row=3, columnspan=2, pady=10)
app.mainloop()
